# Clean-the-Environment-App
I am uploading this project since this is my own, original work that I've spent a lot of time working on. These are programmed in MIT App Inventor & Microsoft Visual Studio with educational purposes. There is also a .apk file for your download! Please enjoy this simple game!
